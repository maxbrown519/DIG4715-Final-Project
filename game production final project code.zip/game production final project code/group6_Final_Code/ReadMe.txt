controls-
WASD - movement
MOUSE MOVEMENT - character rotation
RIGHT CLICK - fire grappling hook (currently fires correctly but can not swing from it yet)
LEFT CLICK - shoot projectile (used to open lock doors and destroy hostiles)
SPACE BAR - jump. if the player is already in the air they can double jump one time before landing
ENTER - air dash. moves character forward while jumping can be done one time before landing

ITEMS IN GAME
ORANGE PLATFORM - climbable object. shoot the grappling hook to swing from and jump to end swinging
RED BOX - bull's eye. shoot with projectile to open door
WHITE BOX - door
OTHER COLORED PLATFORMS - moving platforms each one moves in a specific direction
RED RECTANGLE - hostile. does not move or damage player yet for the sake of testing the other mechanics.