﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hookScript : MonoBehaviour
{
    public GameObject endPoint;
    public GameObject player;
    public GameObject hookable;
    public Transform EP;
    public float speed;
    public bool attached;
    public bool reversed;
    public HingeJoint hinge;
    // Start is called before the first frame update
    void Start()
    {
        endPoint = GameObject.Find("hook distance");
        EP = endPoint.transform;
        attached = false;
    }

    // Update is called once per frame
    void Update()
    {
        StartCoroutine(inUse());

        //transform.Translate(Vector3.forward * speed * Time.deltaTime);
    }

    private void OnCollisionEnter(Collision other)
    {
        

        if (other.gameObject.tag == "Player")
        {
            Destroy(this.gameObject);
        }
        if (other.gameObject.tag == "hookable")
        {
            speed = 0;
            //hinge = this.gameObject.AddComponent<HingeJoint>();
            //hinge.connectedBody = hookable.GetComponent<Rigidbody>();
            attached = true;
        }
      /*  if (other.gameObject.tag == "hook end")
        {
            reversed = true;
        }
        if (reversed == true)
        {
            speed = -speed;
        }*/

        if (attached == true)
        {
           hinge = this.gameObject.AddComponent<HingeJoint>();

        }

        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "hook end")
        {
            reversed = true;
        }
        if (reversed == true)
        {
            speed = -speed;
        }

        if ( other.gameObject.tag == "Player" && reversed == true)
        {
            Destroy(this.gameObject);
        }
    }

    IEnumerator inUse()
    {
        //transform.Translate(Vector3.forward * speed * Time.deltaTime);

        if (attached == true)
        {
            yield return speed = 0;
        } if (attached == false)
        {
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
       yield return new WaitForSeconds(5);
             if(attached == false)
              {
                 Destroy(this.gameObject, 3);
              } else if (attached == true)
                {
                 yield return speed = 0;
                }    
        }

    }

}
